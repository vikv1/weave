from sympy.core._print_helpers import Printable

# alias for compatibility
Printable.__module__ = __name__
DefaultPrinting = Printable
